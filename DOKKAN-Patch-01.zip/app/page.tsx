import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { REDA_STORE_ID } from '@/lib/reda-scope'

export default async function Home() {
  const supabase = await createClient()
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) redirect('/login')

  const { data: membership, error: membershipError } = await supabase
    .from('dokkan_members')
    .select('id')
    .eq('store_id', REDA_STORE_ID)
    .eq('user_id', user.id)
    .eq('status', 'active')
    .maybeSingle()

  if (membershipError) throw new Error('تعذر التحقق من عضوية المتجر')
  if (!membership) redirect('/onboarding/store')

  redirect('/dashboard')
}
