'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'

export async function createMerchantStore() {
  const supabase = await createClient()
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return { error: 'انتهت جلسة الدخول. سجّل الدخول مرة أخرى.' }
  }

  // The production database already contains the initial DOKKAN store,
  // its main branch, and its settings. This RPC safely grants the first
  // owner membership without creating a second store with a different ID.
  const { error } = await supabase.rpc('dokkan_bootstrap_owner')

  if (error) {
    if (error.message.includes('store already has an owner')) {
      return { error: 'المتجر تم تفعيله بالفعل بواسطة حساب مالك آخر. تواصل مع مسؤول النظام.' }
    }
    if (error.message.includes('not authenticated')) {
      return { error: 'انتهت جلسة الدخول. سجّل الدخول مرة أخرى.' }
    }

    console.error('[onboarding] owner bootstrap failed:', error.code)
    return { error: 'تعذر تفعيل المتجر الآن. حاول مرة أخرى.' }
  }

  revalidatePath('/')
  revalidatePath('/dashboard')
  return { ok: true }
}
